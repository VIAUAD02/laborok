﻿import { Game } from './game';
import { SocketServer } from './socketserver';


$(() => {
    const game = new Game();
});


const server = new SocketServer();

server.send("setName", "John Doe");

let guess = 0;
setInterval(() => server.send("guess", null, ++guess), 100);
