# labor13-start

Kiinduló projekt a Mobil és webes szoftverek 13. laborjához (Haladó JavaScript)

Laboranyag: https://github.com/VIAUAC00/Web-labor/tree/master/Labor13
