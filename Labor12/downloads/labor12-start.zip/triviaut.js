$(() => {
    $("#lets-play-button").on("click", () => {
        $("#lets-play-section, #start-game-form-section").toggle();
        $.get("start-game-form-contents.html")
            .then(html => $("#start-game-form")
                .html($(html).each((_, e) => $(e).children("select").removeAttr("disabled")))
                .on("submit", e => { // közvetlenül a HTML beszúrása után lácolhatjuk a 'submit' eseményre történő feliratkozást
                    e.preventDefault(); // a böngésző alapértelmezett működését megállítjuk, amivel újratöltené az oldalt
                    console.log($("#start-game-form select"));
                    $("#start-game-form button[type='submit']").attr("disabled", true); // a Go! gombot letiltjuk, hogy ne lehessen újra API kérést indítani, amíg meg nem érkezett a válasz

                    $.get(`https://opentdb.com/api.php?type=multiple&encode=base64&${$("#start-game-form").serializeArray().map(e => `${e.name.substr(7)}=${e.value}`).join('&')}`)
                        .then(data => {
                            remainingQuestions = data.results;
                            console.log(remainingQuestions);
                            currentQuestion = 0;
                            $("#total-questions").text(remainingQuestions.length);
                            $("#start-game-form button[type='submit']").removeAttr("disabled");
                            getNextQuestion();
                        });
                }));
    });
});

let remainingQuestions, totalQuestions, currentQuestion, correctAnswerIndex;

function getNextQuestion() {
    currentQuestion++;
    const question = remainingQuestions.pop();
    correctAnswerIndex = Math.floor(Math.random() * 4);
    const questions = question.incorrect_answers.slice();
    questions.splice(correctAnswerIndex, 0, question.correct_answer);
    if (question === undefined) {
        // TODO: nincs több kérdés!
        return;
    }
    $(".answer .correct, .answer .incorrect, #next-question").hide();
}
