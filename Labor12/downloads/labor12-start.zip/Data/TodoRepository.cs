﻿using System;
using System.Collections.Generic;
using System.Linq;
using TodoApi.Models;

namespace TodoApi.Data
{
    public class TodoRepository
    {
        private object SyncRoot { get; } = new object();
        private void Synchronized(Action action) { lock (SyncRoot) { action(); } }
        private T Synchronized<T>(Func<T> function) { lock (SyncRoot) { return function(); } }
        private List<Todo> Todos { get; } = new List<Todo>();

        public IEnumerable<Todo> GetAll() => Synchronized(() => Todos.AsEnumerable());
        public void Modify(Todo todo) => Synchronized(() =>
        {
            var old = Todos.Find(t => t.Id == todo?.Id);
            if (old == null)
                return;
            old.Name = todo.Name;
            old.State = todo.State;
            old.Tags = todo.Tags;
        });
        public void Add(Todo todo) => Synchronized(() =>
        {
            todo.Id = Todos.Select(t => t.Id).DefaultIfEmpty(0).Max() + 1;
            Todos.Add(todo);
        });
        public void Delete(int todoId) => Synchronized(() => Todos.RemoveAll(t => t.Id == todoId));
    }
}
