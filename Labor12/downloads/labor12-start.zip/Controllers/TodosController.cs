﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using TodoApi.Data;
using TodoApi.Models;

namespace TodoApi.Controllers
{
    [Route("api/todos")]
    public class TodosController : Controller
    {
        public TodosController(TodoRepository todoRepository) => TodoRepository = todoRepository;
        public TodoRepository TodoRepository { get; }

        [HttpGet]
        public IEnumerable<Todo> Get() => TodoRepository.GetAll();
        [HttpPost]
        public void Post([FromBody]Todo todo) => TodoRepository.Add(todo);
        [HttpPut]
        public void Put([FromBody]Todo todo) => TodoRepository.Modify(todo);
        [HttpDelete]
        public void Delete(int todoId) => TodoRepository.Delete(todoId);
    }
}