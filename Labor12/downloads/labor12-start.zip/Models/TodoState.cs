﻿namespace TodoApi.Models
{
    public enum TodoState
    {
        Active,
        Inactive,
        Done
    }
}
