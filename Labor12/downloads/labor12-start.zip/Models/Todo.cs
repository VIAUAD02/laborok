﻿namespace TodoApi.Models
{
    public class Todo
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public TodoState State { get; set; }
        public string[] Tags { get; set; }
    }
}
