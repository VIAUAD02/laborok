﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Swagger;
using TodoApi.Data;

namespace TodoApi
{
    public class Startup
    {
        public void ConfigureServices(IServiceCollection services) =>
            services.AddSingleton<TodoRepository>()
                .AddSwaggerGen(c => c.SwaggerDoc("v1", new Info { Title = "Mobweb Todos", Version = "v1" }))
                .AddMvc();

        public void Configure(IApplicationBuilder app, ILoggerFactory loggerFactory)
        {
            loggerFactory.AddConsole()
                .AddDebug();
            app.UseDefaultFiles()
                .UseStaticFiles()
                .UseSwagger()
                .UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "Mobweb Todos v1"))
                .UseMvc();
        }
    }
}
